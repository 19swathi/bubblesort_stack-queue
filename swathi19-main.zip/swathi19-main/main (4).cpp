#include<iostream>
using namespace std;
int main()
{

int mynumbers[5] = {10,20,30,40,50};
cout << sizeof(mynumbers)<<endl;
cout << sizeof(int)<<endl;
}